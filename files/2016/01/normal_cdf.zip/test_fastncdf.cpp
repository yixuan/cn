#include <Rcpp.h>

double fastncdf_pos(const double& x)
{
    #include "fastncdf_data.h"

    if(x >= fastncdf_max)  return 1.0;

    const int i = (int)(x * fastncdf_hinv);
    const double w = (x - fastncdf_x[i]) * fastncdf_hinv;
    return w * fastncdf_y[i + 1] + (1.0 - w) * fastncdf_y[i];
}

double fastncdf(const double& x)
{
    if(x < 0)
        return 1.0 - fastncdf_pos(-x);

    return fastncdf_pos(x);
}

using namespace Rcpp;

// [[Rcpp::export]]
NumericVector r_fastncdf(NumericVector x)
{
    const int n = x.size();
    NumericVector res(n);
    double* px = x.begin();
    double* pr = res.begin();
    for(int i = 0; i < n; i++)
        pr[i] = fastncdf(px[i]);
    return res;
}
