library(Rcpp)
sourceCpp("test_as26217.cpp")
sourceCpp("test_fastncdf.cpp")

x = seq(-6, 6, by = 1e-6)
system.time(y <- pnorm(x))

system.time(asy <- r_as26217ncdf(x))
max(abs(y - asy))

system.time(fasty <- r_fastncdf(x))
max(abs(y - fasty))
