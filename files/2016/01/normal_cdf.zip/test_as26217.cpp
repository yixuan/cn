#include <Rcpp.h>

inline double as26217ncdf(double x)
{
    // constants
    static const double a1 =  0.254829592;
    static const double a2 = -0.284496736;
    static const double a3 =  1.421413741;
    static const double a4 = -1.453152027;
    static const double a5 =  1.061405429;
    static const double p  =  0.3275911;

    // Save the sign of x
    const int sign = (x > 0.0) - (x < 0.0);
    x = std::abs(x) * 0.707106781186547524400844362105;

    // A&S formula 7.1.26
    const double t = 1.0 / (1.0 + p * x);
    const double y = 1.0 - (((((a5*t + a4)*t) + a3)*t + a2)*t + a1) * t * std::exp(-x * x);

    return 0.5 * (1.0 + sign * y);
}

using namespace Rcpp;

// [[Rcpp::export]]
NumericVector r_as26217ncdf(NumericVector x)
{
    const int n = x.size();
    NumericVector res(n);
    double* px = x.begin();
    double* pr = res.begin();
    for(int i = 0; i < n; i++)
        pr[i] = as26217ncdf(px[i]);
    return res;
}
